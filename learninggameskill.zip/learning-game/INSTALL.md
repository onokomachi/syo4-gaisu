# インストール方法

このフォルダ（learning-game/）を丸ごと、次のいずれかに置いてください。

## A. いつでも使えるようにする（個人スキル・PCのClaude Code/デスクトップアプリ）
~/.claude/skills/learning-game/SKILL.md となるように配置
（フォルダごとコピー: ~/.claude/skills/learning-game/）

## B. 特定のリポジトリで使う（claude.ai のWeb版セッションでも有効）
<リポジトリ>/.claude/skills/learning-game/SKILL.md となるように配置してコミット
（Web版のクラウド環境はリポジトリの中身しか持ち込めないため、この方法が確実です）

## 使い方
/learning-game 小4 算数 わり算の筆算
/learning-game 中1 国語 少年の日の思い出（本文は後で貼り付け）

スキルは、情報が不足していれば実装せず質問を繰り返し、
揃ったらリサーチ→設計→実装→検証→PR作成までループで自走します。
