# ゲーミフィケーション仕様（syo4-syousu / wari-hissann3 由来）

参考リポジトリ（`onokomachi/syo4-syousu`、または本仕様を実装済みの `onokomachi/wari-hissann3`）
にアクセスできる場合は **clone してコードを直接コピー**するのが最速。できない場合は本仕様から再実装する。

## 技術スタック

- Vite + React 19 + TypeScript + Tailwind CSS v4（`@tailwindcss/vite`）
- zustand（persist で localStorage 永続化）、motion（アニメ）、canvas-confetti、lucide-react
- 効果音は Web Audio API でその場合成（音声ファイル不要）

## ファイル構成（コピー元 → 配置先）

| ファイル | 役割 | 改変ポイント |
|---|---|---|
| `src/store/progressStore.ts` | スキル別習熟度・累計・連続記録・テスト自己ベスト | ModuleId 一覧と `skillToModuleId()` の prefix を単元用に |
| `src/store/settingsStore.ts` | テーマ・文字サイズ・効果音設定 | localStorage キー名 |
| `src/services/progressRepository.ts` | 保存先の抽象化（localStorage アダプタ） | 旧データがあれば移行処理を追加 |
| `src/lib/badges.ts` | バッジ計算（純粋関数） | 最終称号「【単元名】神」等の文言 |
| `src/lib/themeUnlock.ts` | バッジ獲得率→テーマ解放 | そのまま |
| `src/lib/praise.ts` | プロセス称賛・励まし文言 | そのまま |
| `src/lib/sound.ts` | 正解ポン/クリア上昇音/レベルアップ/やわらかい再挑戦音 | そのまま |
| `src/lib/useAdaptive.ts` | 適応難易度フック | そのまま |
| `src/lib/review.ts` | ふくしゅう対象の抽出 | prefix 対応 |
| `src/lib/useApplySettings.ts` | テーマ/文字サイズを DOM に反映 | そのまま |
| `src/components/ui/primitives.tsx` | Button/Card/HintBox/ResultPanel/SetupScreen/LevelCard/MasteryBar | 「〈単元名〉ランドへ」の戻りラベル |
| `src/components/ui/GoalRing.tsx` | きょうの目標リング | そのまま |
| `src/components/ui/{Matrix,DeepSea,Aurora,Cosmos}Rain.tsx` | テーマ別の動く背景 | そのまま |
| `src/components/shared/{Keypad,AnswerEntry,AppShell,AdaptiveBar}.tsx` | 共通入力・共通枠 | そのまま |
| `src/components/{Hub,Settings,LogView}.tsx` | ホーム/設定/学習のきろく | モジュール一覧・アイコン・タイトル |
| `src/index.css` | テーマトークン（`--c-*`）＋テーマ別一括上書きCSS | そのまま＋アプリ固有クラス |
| `index.html` | FOUC（白フラッシュ）防止スクリプト | localStorage キー名・タイトル |

## 機能一覧（全部入れる）

1. **進捗ストア**: `recordResult({moduleId, skillId, label, correct})` を全モジュールが呼ぶ。
   - mastery: skillId ごとの attempts/corrects/perfectStreak（5でMAX、ミスで0）
   - currentStreak/maxStreak（全体の連続ノーミス）、totalCorrect・moduleCounts（累計。logs は直近200件で打ち切るため別持ち）
   - masteredModules（5連続ノーミス達成の永続記録）、bestTestOmote/Ura/Total
2. **バッジ（計算は純粋関数）**: はじめの一歩(1問) / がんばり20・30・50・100 /
   ノーミス5・10・20・30・50 / 表テスト50・75・90・満点 / 裏テスト25・40・満点 /
   両面テスト75・100・140・満点 / 各モジュール「デビュー」(1問) / 各モジュール「マスター」(習熟度MAX) /
   最終称号「【単元名】神」（他の全バッジ獲得で解放、金グラデで特別表示）
3. **テーマ解放**: light・和(cream)・マトリックス(dark) は最初から。バッジ獲得率で
   深海50%・極光75%・宇宙神100%。ダーク系テーマはハードコードされた明色クラスを CSS で一括上書き。
4. **きょうの目標リング**: 今日の正解数/目標（タップで 5→10→15→20 切替）。達成で色が変わる。
5. **おまかせモード（適応難易度）**: レベル配列＋prefix を渡すと、習熟度≥0.7 のレベルを
   スキップして開始位置を推定。セッション中は「2問連続ノーミス→レベルアップ（ファンファーレ＋
   AdaptiveBar 演出）」「2問連続ミス→レベルダウン」。
6. **ふくしゅうコーナー**: 試行2回以上かつ正答率<70% のスキルを最大3件、ホームに提案チップ表示。
7. **効果音**: 正解ポン(880Hz)/クリア(ドミソ上昇)/レベルアップ(ファンファーレ)/
   再挑戦(330Hz低め短音、不快でない)。設定でOFF可。ブザー音は使わない。
8. **称賛/励まし**: パーフェクト時・完答時・ミス時でランダム文言。能力でなく
   「やり方・粘り」を称賛、ミスは「学びのたね」とノーマライズ。
9. **学習のきろく**: サマリー4カード（今日/累計/連続中/最高連続）＋モジュール別クリア数
   （すべて/今日切替）＋バッジ横スクロール一覧＋履歴（テストは答案詳細を展開表示）。
10. **本番テストモード**: 表/裏/ぜんぶ の範囲選択 → 全問を先に生成して固定 → 1問ずつ既存
    Round コンポーネントで解く（ヘッダに大問番号・進捗バー、得点は隠す）→ 結果画面
    （合計点・大問別○×・正答一覧）→ 詳細つきで記録。**一発正解のみ得点**（onResult は
    最初の1回だけ採用）。まちがえても正しい答えまで進める（学習機会は保証）。
11. **1問の共通フロー**: 出題 → 誤答なら HintBox に理由＋次の一手（精緻化フィードバック）→
    正解で confetti＋ResultPanel（称賛＋解説＋つぎのもんだい）→ recordResult。
    Round コンポーネントに分離し、`problem`/`onNext`/`onResult`/`nextLabel` props で
    本番テストから再利用できるようにする。

## 実装ノート

- 各モジュールのおまかせ用 useAdaptive は `useAdaptive(LEVEL_IDS, '<prefix>')`。
- confetti は `{ particleCount: 110-150, spread: 65-70, origin: { y: 0.6 } }`。
- ResultPanel の accent 色はモジュールのアクセントカラーに合わせる。
- Tailwind のパージ対策: アクセント色クラスは静的なマップで定義する。
- 進捗の記録・バッジ判定はすべて localStorage（サーバー不要）。キーはアプリ固有に。
