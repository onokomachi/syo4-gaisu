# 新規アプリの土台づくり（対象アプリが存在しない場合）

セッション内に対象アプリが無い場合は、以下で0から作る。参考リポジトリ
（syo4-syousu / wari-hissann3）が clone できるなら、**そのリポジトリを丸ごとコピーして
単元用に置き換える**方が速い（不要モジュールを削除 → 問題ジェネレーターとモジュールを差し替え）。

## package.json（依存の基準）

```json
{
  "name": "<app-name>",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite --port=3000 --host=0.0.0.0",
    "build": "vite build",
    "preview": "vite preview",
    "lint": "tsc --noEmit"
  },
  "dependencies": {
    "@tailwindcss/vite": "^4.1.14",
    "@types/canvas-confetti": "^1.9.0",
    "@vitejs/plugin-react": "^5.0.4",
    "canvas-confetti": "^1.9.4",
    "lucide-react": "^0.546.0",
    "motion": "^12.23.24",
    "react": "^19.0.1",
    "react-dom": "^19.0.1",
    "vite": "^6.2.3",
    "zustand": "^5.0.14"
  },
  "devDependencies": {
    "@types/node": "^22.14.0",
    "tailwindcss": "^4.1.14",
    "tsx": "^4.21.0",
    "typescript": "~5.8.2"
  }
}
```

## ディレクトリ構成

```
index.html                 … タイトル＋テーマFOUC防止スクリプト（gamification.md 参照）
vite.config.ts             … react() + tailwindcss() プラグイン
src/
  main.tsx                 … ReactDOM.createRoot で <App/>
  App.tsx                  … ハブ型ルーティング（HUB / MODULE / TEST / LOG）＋テーマ背景
  index.css                … テーマトークン＋テーマ別上書き（参考リポジトリからコピー）
  constants.ts             … MODULES（id/title/description/icon/accent/status）
  types.ts                 … アプリ固有の型
  store/  progressStore.ts settingsStore.ts
  services/ progressRepository.ts
  lib/    problems.ts（問題ジェネレーター集・純粋関数） testConfig.ts（本番テスト構成）
          badges.ts praise.ts sound.ts themeUnlock.ts useAdaptive.ts review.ts useApplySettings.ts
  components/
    Hub.tsx Settings.tsx LogView.tsx
    ui/     primitives.tsx GoalRing.tsx MatrixRain.tsx DeepSeaRain.tsx AuroraRain.tsx CosmosRain.tsx
    shared/ Keypad.tsx AnswerEntry.tsx QuotRemEntry.tsx AppShell.tsx AdaptiveBar.tsx
    modules/ <各問題モジュール>.tsx MockTestModule.tsx
```

## 各モジュールの共通パターン（コピペ用の骨格）

```tsx
export const XxxModule = ({ onExit }) => {
  const [mode, setMode] = useState<'setup'|'level'|'auto'>('setup');
  const [level, setLevel] = useState<XxxLevel>(LEVELS[0].id);
  const [round, setRound] = useState(0);
  const adaptive = useAdaptive(LEVEL_IDS, '<prefix>');
  // setup: SetupScreen + LevelCard(習熟バー・今日のクリア数) + おまかせボタン
  // play : AppShell + (auto && AdaptiveBar) + <XxxRound key={`${activeLevel}-${round}`} … />
};

export const XxxRound = ({ level, problem: given, onNext, onResult, nextLabel }) => {
  const [problem] = useState(() => given ?? generateXxx(level));
  // 出題カード → (誤答: HintBox に理由と次の一手) → 正解: confetti + recordResult + ResultPanel
};
```

Round が `problem`/`onResult`/`nextLabel` を受け取れるようにしておくと、
本番テストモード（MockTestModule）が全モジュールを1問ずつ再利用できる。

## 検証コマンド

```bash
npm install
npm run lint          # tsc --noEmit
npm run build         # vite build
npx tsx <プロパティテストスクリプト>
npm run dev &         # Playwright でスモークテスト（スクリーンショット確認）
```
